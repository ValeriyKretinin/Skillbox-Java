import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Loader {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/skillbox?useUnicode=true&serverTimezone=UTC";
        String user = "root";
        String pass = "Vx1358";

        try {
            Connection connection = DriverManager.getConnection(url, user, pass);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT course_name, COUNT(*)/(MAX(MONTH(subscription_date))-MIN(MONTH(subscription_date))+1) as subscription_per_month FROM purchaselist GROUP BY course_name");
            while (resultSet.next()){
                String count = resultSet.getString("subscription_per_month");
                String courseName = resultSet.getString("course_name");
                System.out.println(courseName + " - Среднее число покупок в месяц: \n" + count);
            }
            resultSet.close();
            statement.close();
            connection.close();

        }
        catch (Exception ex){
            ex.printStackTrace();
        }

    }
}
