import core.Line;
import core.Station;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RouteCalculatorTest extends TestCase
{
    Line line1 = new Line(1, "Первая");
    Line line2 = new Line(2, "Вторая");
    Line line3 = new Line(3, "Третья");
    List<Station> route;
    RouteCalculator calculator;
    Station a = new Station("Приморская", line1);
    Station b = new Station("Василеостровская", line1); //2.5
    Station c = new Station("Гостиный двор", line2); // + 3.5
    Station d = new Station("Невский проспект", line2);// + 2.5
    Station e = new Station("Арбузная", line3); // + 3.5
    Station f = new Station("Морковная", line3);// + 2.5 = 14,5 мин

    StationIndex stationIndex;

    @Override
    protected void setUp() throws Exception
    {
        StationIndex stationIndex = new StationIndex();
        route = new ArrayList<>();
        line1.addStation(a);
        line1.addStation(b);
        line2.addStation(c);
        line2.addStation(d);
        line3.addStation(e);
        line3.addStation(f);
        route.add(a);
        route.add(b);
        route.add(c);
        route.add(d);
        route.add(e);
        route.add(f);
        stationIndex.addStation(a);
        stationIndex.addStation(b);
        stationIndex.addStation(c);
        stationIndex.addStation(d);
        stationIndex.addStation(e);
        stationIndex.addStation(f);
        stationIndex.addLine(line1);
        stationIndex.addLine(line2);
        stationIndex.addLine(line3);
        calculator = new RouteCalculator(stationIndex);

        List<Station> connectionStations = new ArrayList<>();
        connectionStations.add(a);
        connectionStations.add(c);
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(d);
        connectionStations.add(b);
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(a);
        connectionStations.add(e);
        connectionStations.add(f);
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

    }
    public void testCalculateDuration()
    {
        double actual = RouteCalculator.calculateDuration(route);
        double expected = 14.5;
        assertEquals(expected, actual);
    }
    public void testGetRouteOnTheLine()
    {
        List<Station> actual = calculator.getShortestRoute(a, b);
        List<Station> expected = Arrays.asList(a, b);
        assertEquals(expected, actual);

    }
    public void testGetRouteWithOneConnection()
    {
        List<Station> actual = calculator.getShortestRoute(a, d);
        List<Station> expected = Arrays.asList(a, c, d);
        assertEquals(expected, actual);

    }
    public void testGetRouteWithTwoConnections()
    {
        List<Station> actual = calculator.getShortestRoute(a, e);
        List<Station> expected = Arrays.asList(a, e);
        assertEquals(expected, actual);
    }

}
