import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        int a = 30;
        int b = 20;
        int c = a > b ? a : b;
        System.out.println(c);


        String[] strings = {"Hello", "hi", "how are you today?"};

        for (int i = strings.length - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if (strings[j].length() > strings[j + 1].length()) {
                    String tmp = strings[j];
                    strings[j] = strings[j + 1];
                    strings[j + 1] = tmp;
                }
            }
        }

        for (String string : strings) {
            System.out.println(string);
        }
    }

}

