public interface Employee {

    public int getMonthSalary();

}
