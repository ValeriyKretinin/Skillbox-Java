public class TopManager extends Company implements Employee{
    double salary;
    public TopManager()
    {
        double fix = 90000 + (1000 * Math.random());
        if (getIncome() > 10000000)
        {
            salary = fix + (fix * 1.5);
        }
        else {
            salary = fix;
        }
    }
    @Override
    public int getMonthSalary() {
        return (int) salary;
    }
}
