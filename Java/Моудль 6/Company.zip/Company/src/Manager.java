public class Manager implements Employee {
    double salary;
    public Manager()
    {
        double fix = 50000 + (1000 * Math.random());
        double income = 357678;
        salary = fix + (0.05 * income);
    }
    @Override
    public int getMonthSalary() {
        return (int) salary;
    }
}
