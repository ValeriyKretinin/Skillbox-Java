public class Operator implements Employee {
    double salary;
    public Operator(){
        salary = 40000 + (1000 * Math.random());
    }
    @Override
    public int getMonthSalary() {
        return (int) salary;
    }
}
