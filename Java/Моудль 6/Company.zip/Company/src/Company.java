import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class Company {


    private ArrayList<Employee> list = new ArrayList<>();

    private double income = 10000010;

    public void hire(Employee employee)
    {
        list.add(employee);
    }

    public void hireAll(List<Employee> employee)
    {
        list.addAll(employee);
    }

    public void fire(Employee employee)
    {
        list.remove(employee);
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public List<Employee> getTopSalaryStaff(int count)
    {
        list.sort(new CompanyComparator());
        Collections.reverse(list);
        return list.subList(0, count);
    }
    public List<Employee> getLowestSalaryStaff(int count)
    {
        list.sort(new CompanyComparator());
        return list.subList(0, count);
    }
}
