import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Company company = new Company();
        List<Employee> list = new ArrayList<>();

        for (int managerCount = 1; managerCount <= 80; managerCount++) {
            Manager manager = new Manager();
            list.add(manager);
        }
        for (int topManagerCount = 1; topManagerCount <= 10; topManagerCount++) {
            TopManager topManager = new TopManager();
            list.add(topManager);
        }
        for (int operatorCount = 1; operatorCount <= 180; operatorCount++) {
            Operator operator = new Operator();
            list.add(operator);
        }
        company.hireAll(list);

        List<Employee> topSalaryStaffList = company.getTopSalaryStaff(10);
        System.out.println("Самые высокие зарплаты: ");
        for (Employee e : topSalaryStaffList)
        {
            System.out.println(e.getMonthSalary() + " руб.");
        }
        List<Employee> lowSalaryStaffList = company.getLowestSalaryStaff(30);
        System.out.println("Самые низкие зарплаты: ");
        for (Employee e : lowSalaryStaffList)
        {
            System.out.println(e.getMonthSalary() + " руб.");
        }

        System.out.println("Увольнение 50% сотрудников компании");
        for (int i = 1; i <= 135; i++)
        {
            company.fire(list.get(i));
        }

        List<Employee> topSalaryStaffList1 = company.getTopSalaryStaff(10);
        System.out.println("Самые высокие зарплаты после увольнения: ");
        for (Employee e : topSalaryStaffList1)
        {
            System.out.println(e.getMonthSalary() + " руб.");
        }
        List<Employee> lowSalaryStaffList1 = company.getLowestSalaryStaff(30);
        System.out.println("Самые низкие зарплаты после увольнения: ");
        for (Employee e : lowSalaryStaffList1)
        {
            System.out.println(e.getMonthSalary() + " руб.");
        }
    }
}
