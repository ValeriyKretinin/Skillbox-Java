public class IndividualЕntrepreneur extends Client {

    IndividualЕntrepreneur(double balance) {
        super(balance);
    }

    @Override
    public double getBalance() {
        return super.getBalance();
    }

    @Override
    public void addMoney(double money) {
        if (money < 1000)
        {
            double fee = money * 0.01;
            setBalance(getBalance() + (money - fee));
        }
        else {
            double fee = money * 0.005;
            setBalance(getBalance() + (money - fee));
        }
}

    @Override
    public void getMoney(double money)
    {
        if (money <= getBalance())
        {
        setBalance(getBalance() - money);
    }
        else {
            System.out.println("Недостаточно средств для снятия");
        }
    }
}

