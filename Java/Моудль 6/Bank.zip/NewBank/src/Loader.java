public class Loader {
    public static void main(String[] args) {


        Client individual = new Individual(10990);
        Client entity = new Entity(9000);
        Client individualЕntrepreneur = new IndividualЕntrepreneur(100);



        System.out.println("\nОперации со счетом физического лица: \nБаланс равен: " + individual.getBalance());
        System.out.println("Пополнение на баланса");
        individual.addMoney(1000);
        System.out.println("Баланс после пополнения равен: " + individual.getBalance());
        individual.getMoney(500);
        System.out.println("Баланс после снятия равен: " + individual.getBalance());

        System.out.println("\nОперации со счетом юридического лица: \nБаланс равен: " + entity.getBalance());
        System.out.println("Пополнение баланса");
        entity.addMoney(1000);
        System.out.println("Баланс после пополнения равен: " + entity.getBalance());
        entity.getMoney(500);
        System.out.println("Баланс после снятия равен: " + entity.getBalance());

        System.out.println("\nОперации со счетом индивидуального предпринимателя: \nБаланс равен: " + individualЕntrepreneur.getBalance());
        System.out.println("Пополнение баланса");
        individualЕntrepreneur.addMoney(10000);
        System.out.println("Баланс после пополнения равен: " + individualЕntrepreneur.getBalance());
        individualЕntrepreneur.getMoney(10000);
        System.out.println("Баланс после снятия равен: " + individualЕntrepreneur.getBalance());
    }
}
