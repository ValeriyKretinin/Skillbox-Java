public class Entity extends Client {

    Entity(double balance) {
        super(balance);
    }

    @Override
    public double getBalance() {
        return super.getBalance();
    }

    @Override
    public void addMoney(double money) {
        setBalance(getBalance() + money);
    }

    @Override
    public void getMoney(double money) {
        double fee = money * 0.01;
        if (money + fee <= getBalance())
        {
        setBalance(getBalance() - (money + fee));
    }
        else {
            System.out.println("Недостаточно средств для снятия");
        }
    }
}
