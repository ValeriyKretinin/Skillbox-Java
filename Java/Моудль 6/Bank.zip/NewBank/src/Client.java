public abstract class Client   {
    private double balance;
    Client(double balance)
    {
        this.balance = balance;
    }

    public double getBalance(){
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }


    public abstract void addMoney(double money);
    public abstract void getMoney(double money);

}