public class Individual extends Client {

    Individual(double balance) {
        super(balance);
    }

    @Override
    public double getBalance() {
        return super.getBalance();
    }


    @Override
    public void addMoney(double money) {
        setBalance(getBalance() + money);
    }

    @Override
    public void getMoney(double money) {
        if (money <= getBalance()) {
            setBalance(getBalance() - money);
        }
        else {
            System.out.println("На счету недостаточно средств для снятия");
        }
    }
}
