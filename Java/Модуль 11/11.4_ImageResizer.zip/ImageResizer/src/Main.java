
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main
{
    private static final int newWidth = 300;
    private static final int threads = Runtime.getRuntime().availableProcessors();

    public static void main(String[] args)
    {
        String srcFolder = "C:\\Users\\Валерий\\Desktop\\src";
        String dstFolder = "C:\\Users\\Валерий\\Desktop\\dst";

        File srcDir = new File(srcFolder);
        long start = System.currentTimeMillis();
        File[] files = srcDir.listFiles();
        ExecutorService service = Executors.newFixedThreadPool(threads);

        try {
            for (int i = 0; i < threads; i++) {
                service.submit(new ImageResizer(files, newWidth, dstFolder, start));
            }
            service.shutdown();
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
