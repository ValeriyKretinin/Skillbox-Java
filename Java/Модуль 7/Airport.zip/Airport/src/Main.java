import com.skillbox.airport.Airport;
import com.skillbox.airport.Flight;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Airport airport = Airport.getInstance();
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar2.add(Calendar.HOUR_OF_DAY, 2);
        Date d = calendar1.getTime();
        Date d2 = calendar2.getTime();

        airport.getTerminals().stream().flatMap(t -> t.getFlights().stream())
                .filter(flight -> flight.getDate().after(d) && flight.getDate().before(d2) && flight.getType().equals(Flight.Type.DEPARTURE))
                .sorted(Comparator.comparing(Flight::getDate))
                .forEach(flight -> System.out.println(flight.getAircraft().getModel() + "\t" + flight));

    }

}
