import java.util.ArrayList;
import java.util.List;

public class Line {

    private int number;
    private String name;
    private List<Station> stations;

    public Line(int number, String name){
        this.name = name;
        this.number = number;
        stations = new ArrayList<>();
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public List<Station> getStations() {
        return stations;
    }



}
