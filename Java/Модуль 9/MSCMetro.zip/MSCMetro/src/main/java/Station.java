public class Station {

    private Line line;
    private String name;

    public Station (Line line, String name){
        this.line = line;
        this.name = name;
    }

    public Line getLine() {
        return line;
    }

    public String getName() {
        return name;
    }
}
