import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class Main {
    public static void main(String[] args) throws IOException {
        File folder = new File("C:\\Users\\Валерий\\Videos\\Captures");
        File[] listFiles = folder.listFiles();
        Path copyFolder = Paths.get("E:\\Captures");

        if (Files.exists(copyFolder)) {
            if (listFiles != null) {
                for (File file : listFiles) {
                    Files.copy(file.toPath(), copyFolder.resolve(file.getName()), StandardCopyOption.REPLACE_EXISTING);
                }
            }

        }
    }
}
