import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    final static int NUMBER_COLUMNS = 11;
    final static int INDEX_INCOME = NUMBER_COLUMNS - 2;
    final static int INDEX_WITHDRAW = NUMBER_COLUMNS -1;
    final static int INDEX_TYPE = NUMBER_COLUMNS - 5;

    public static void main(String[] args) {

        double totalIncome = 0;
        double totalWithdraw = 0;
        List<Statement> statements = new ArrayList<>();

        try {
            List<String> lines = Files.readAllLines(Paths.get("data/movementList.csv"));
            for (int i = 1; i < lines.size(); i++) {
                String[] fragments = lines.get(i).replaceAll("\"", "")
                        .replaceAll(" \\(.*?\\)", "")
                        .replaceAll("809216", "")
                        .replaceAll("\\s{3,}", ",")
                        .split(",", NUMBER_COLUMNS);

                double income = Double.parseDouble(fragments[INDEX_INCOME]);
                double withdraw = Double.parseDouble(fragments[INDEX_WITHDRAW].replaceAll(",", "."));
                totalIncome += income;
                totalWithdraw += withdraw;
                statements.add(new Statement(fragments[INDEX_TYPE], income, withdraw));
            }
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        System.out.println("Общий приход: " + totalIncome + " рублей" + "\nОбщий расход: " + totalWithdraw + " рублей");
        System.out.println("\nПриходы: \n");
        statements.stream()
                .filter(statement -> statement.income > 0)
                .collect(Collectors.groupingBy(Statement::getAgent, Collectors.summingDouble(Statement::getIncome)))
                .forEach((a, income) -> System.out.println(a + " : " + income + " рублей"));

        System.out.println("\nРасходы: \n");
        statements.stream()
                .filter(statement -> statement.withdraw > 0)
                .collect(Collectors.groupingBy(Statement::getAgent, Collectors.summingDouble(Statement::getWithdraw)))
                .forEach((a, withdraw) -> System.out.println(a + " : " + withdraw + " рублей"));

    }

}