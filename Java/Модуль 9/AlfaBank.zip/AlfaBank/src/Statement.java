public class Statement {
    String agent;
    double income;
    double withdraw;

    public Statement(String agent, double income, double withdraw) {
        this.agent = agent;
        this.income = income;
        this.withdraw = withdraw;
    }

    public String getAgent() {
        return agent;
    }

    public double getIncome() {
        return income;
    }

    public double getWithdraw() {
        return withdraw;
    }
}