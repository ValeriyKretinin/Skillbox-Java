import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args) throws IOException {
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        final int KB = 1024;
        final int MB = 1048576;
        final float GB = 1073741824;

        Path folder = Paths.get("C:\\Users\\Валерий\\Videos");
        long size = Files.walk(folder)
                .filter(p -> p.toFile().isFile())
                .mapToLong(p -> p.toFile().length())
                .sum();
        System.out.println("Размер папки в байтах: " + size);
        System.out.println("Размер папки в килобайтах: " + size / KB);
        System.out.println("Размер папки в мегабайтах: " + size / MB);
        System.out.println("Размер папки в гигабайтах: " + decimalFormat.format((double)size / GB));

    }
}
